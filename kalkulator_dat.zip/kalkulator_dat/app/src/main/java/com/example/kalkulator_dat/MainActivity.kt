package com.example.kalkulator_dat

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.DatePicker
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.time.LocalDate
import java.time.Period
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val button = findViewById<Button>(R.id.button_oblicz)
        val data_poczatkowa = findViewById<DatePicker>(R.id.datepicker_datap)
        val data_koncowa = findViewById<DatePicker>(R.id.datepicker_datak)
        val spinnerJednostka = findViewById<Spinner>(R.id.spinner_jednostka)
        val textViewWynik = findViewById<TextView>(R.id.textView_wynik)

        // Setup Spinner adapter
        val jednostki = arrayOf("Dni", "Tygodnie", "Miesiące", "Lata", "Pełny okres")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, jednostki)
        spinnerJednostka.adapter = adapter

        button.setOnClickListener {
            val startDate = LocalDate.of(
                data_poczatkowa.year,
                data_poczatkowa.month + 1,
                data_poczatkowa.dayOfMonth
            )
            val endDate = LocalDate.of(
                data_koncowa.year,
                data_koncowa.month + 1,
                data_koncowa.dayOfMonth
            )

            val selectedUnit = spinnerJednostka.selectedItem.toString()
            val wynikText = when (selectedUnit) {
                "Dni" -> {
                    val days = ChronoUnit.DAYS.between(startDate, endDate)
                    "${abs(days)} dni"
                }
                "Tygodnie" -> {
                    val days = ChronoUnit.DAYS.between(startDate, endDate)
                    val weeks = days.toDouble() / 7.0
                    String.format(Locale.getDefault(), "%.1f tygodni", abs(weeks))
                }
                "Miesiące" -> {
                    val months = ChronoUnit.MONTHS.between(startDate, endDate)
                    "${abs(months)} miesięcy"
                }
                "Lata" -> {
                    val years = ChronoUnit.YEARS.between(startDate, endDate)
                    "${abs(years)} lat"
                }
                "Pełny okres" -> {
                    val p = if (startDate.isBefore(endDate)) {
                        Period.between(startDate, endDate)
                    } else {
                        Period.between(endDate, startDate)
                    }
                    "${p.years} lat, ${p.months} miesięcy, ${p.days} dni"
                }
                else -> {
                    val days = ChronoUnit.DAYS.between(startDate, endDate)
                    "${abs(days)} dni"
                }
            }

            textViewWynik.text = "Wynik: $wynikText"
        }
    }
}
