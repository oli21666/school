﻿#include <iostream>
#include <string>
#include <cctype>

using namespace std;

class Matma {
public:
    int silnia(int n) {
        int wynik = 1;

        for (int i = 1; i <= n; i++) {
            wynik *= i;
        }

        return wynik;
    }

    int fibonacci(int n) {
        int a = 0;
        int b = 1;

        for (int i = 0; i < n; i++) {
            int kolejny = a + b;
            a = b;
            b = kolejny;
        }

        return a;
    }
};

class Okrag {
public:
    double pi = 3.14;

    double pole(double promien) {
        return pi * promien * promien;
    }

    double obwod(double promien) {
        return 2 * pi * promien;
    }
};

int numerFaktury = 0;

void wyswietlFakture(string firma, string ulica, string kod, string miasto) {
    numerFaktury++;

    cout << "\nFaktura nr " << numerFaktury << endl;
    cout << "Firma: " << firma << endl;
    cout << "Ulica: " << ulica << endl;
    cout << "Kod pocztowy: " << kod << endl;
    cout << "Miasto: " << miasto << endl;
}

int policzSamogloski(string napis) {
    int licznik = 0;

    for (int i = 0; i < napis.length(); i++) {
        char znak = tolower(napis[i]);

        if (znak == 'a' || znak == 'e' || znak == 'i' ||
            znak == 'o' || znak == 'u' || znak == 'y') {
            licznik++;
        }
    }

    return licznik;
}

int main() {
 
    for (int i = 0; i < 3; i++) {
        string firma, ulica, kod, miasto;

        cout << "\nPodaj dane firmy " << i + 1 << endl;

        cout << "Nazwa firmy: ";
        getline(cin, firma);

        cout << "Ulica: ";
        getline(cin, ulica);

        cout << "Kod pocztowy: ";
        getline(cin, kod);

        cout << "Miasto: ";
        getline(cin, miasto);

        wyswietlFakture(firma, ulica, kod, miasto);
    }

    for (int i = 0; i < 3; i++) {
        string napis;

        cout << "\nWpisz słowo lub zdanie: ";
        getline(cin, napis);

        cout << "Liczba samogłosek: "
            << policzSamogloski(napis) << endl;
    }

    Matma matematyka;
    int liczba;

    cout << "\nPodaj nieujemną liczbę do obliczenia silni: ";
    cin >> liczba;

    if (liczba >= 0) {
        cout << "Silnia z " << liczba << " wynosi: "
            << matematyka.silnia(liczba) << endl;
    }
    else {
        cout << "Liczba nie może być ujemna." << endl;
    }

    cout << "\nPodaj numer wyrazu ciągu Fibonacciego (od 0): ";
    cin >> liczba;

    if (liczba >= 0) {
        cout << "Wyraz ciągu Fibonacciego nr " << liczba << " wynosi: "
            << matematyka.fibonacci(liczba) << endl;
    }
    else {
        cout << "Numer wyrazu nie może być ujemny." << endl;
    }

    Okrag okrag;
    double promien;

    cout << "\nPodaj promień okręgu: ";
    cin >> promien;

    if (promien >= 0) {
        cout << "Pole okręgu: " << okrag.pole(promien) << endl;
        cout << "Obwód okręgu: " << okrag.obwod(promien) << endl;
    }
    else {
        cout << "Promień nie może być ujemny." << endl;
    }

    return 0;
}